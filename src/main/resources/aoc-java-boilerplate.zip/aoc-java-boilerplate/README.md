# advent-of-code-202x

Instructions for next year:
1. Make a new repo in Github and clone it locally.
2. I made you a [zip](src/main/resources/aoc-java-boilerplate.zip) with the boilerplate files! Just unzip it and add it to new repo.
3. Create a new project in IntelliJ from existing sources.
4. Ready go!